/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lib;

/**
 *
 * @author supra
 */
public class LoginSession {
    
    private static LoginSession mysession = new LoginSession();
    
    private int userid;
    private String nama,level,username;
    
    private LoginSession(){
        
    }

    public static LoginSession getInstance() {
        return mysession;
    }

    public static void setMysession(LoginSession mysession) {
        LoginSession.mysession = mysession;
    }

    public int getUserid() {
        return userid;
    }

    public void setUserid(int userid) {
        this.userid = userid;
    }

    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    
}
